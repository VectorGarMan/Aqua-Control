// Cargar variables de entorno desde archivo .env
require('dotenv').config();

// Importar dependencias necesarias
const express = require('express');  // Framework web
const cors = require('cors');        // Middleware para habilitar CORS
const authRoutes = require('./routes/auth.routes');     // Rutas de autenticación
const consumoRoutes = require('./routes/consumo.routes'); // Rutas de consumo de agua

// Crear instancia de la aplicación Express
const app = express();

// Configurar middleware globales
app.use(cors());           // Habilitar CORS para todas las rutas
app.use(express.json());   // Parser para datos JSON en el body

// Configurar rutas de la API
app.use('/api/auth', authRoutes);     // Montar rutas de autenticación
app.use('/api/consumo', consumoRoutes); // Montar rutas de consumo

// Configurar y iniciar el servidor
const PORT = process.env.PORT || 4000;  // Puerto desde variables de entorno o 4000 por defecto
app.listen(PORT, () => {
  console.log(`API escuchando en puerto ${PORT}`);
});