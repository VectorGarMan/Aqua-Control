// Importar el módulo jsonwebtoken para verificar tokens JWT
const jwt = require('jsonwebtoken');

// Middleware de autenticación para proteger rutas
module.exports = (req, res, next) => {
  // Obtener el header de autorización
  const auth = req.headers.authorization;
  
  // Verificar si existe el header de autorización
  if (!auth) return res.status(401).json({ msg: 'Sin token' });
  
  // Extraer el token del header (formato: "Bearer <token>")
  const token = auth.split(' ')[1];
  
  try {
    // Verificar y decodificar el token usando la clave secreta
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    
    // Agregar el ID del usuario al objeto request para uso posterior
    req.userId = payload.id;
    
    // Continuar con la siguiente función en la cadena de middleware
    next();
  } catch {
    // Responder con error si el token es inválido o ha expirado
    res.status(401).json({ msg: 'Token inválido' });
  }
};