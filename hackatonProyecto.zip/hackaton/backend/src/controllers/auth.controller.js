// Importación de dependencias necesarias
const bcrypt = require('bcryptjs');        // Para el hash y comparación de contraseñas
const jwt = require('jsonwebtoken');        // Para generar tokens JWT
const User = require('../models/user.model'); // Modelo de usuario

// Controlador para el registro de nuevos usuarios
exports.register = async (req, res) => {
  // Extraer datos del cuerpo de la petición
  const { nombre, email, password } = req.body;
  
  // Verificar si el email ya está registrado
  const existing = await User.findByEmail(email);
  if (existing) return res.status(400).json({ msg: 'Email ya registrado' });

  // Crear hash de la contraseña antes de almacenarla
  const hash = await bcrypt.hash(password, 10);
  
  // Crear nuevo usuario en la base de datos
  const userId = await User.create({ nombre, email, password: hash });
  res.status(201).json({ userId });
};

// Controlador para la autenticación de usuarios
exports.login = async (req, res) => {
  // Extraer credenciales del cuerpo de la petición
  const { email, password } = req.body;
  
  // Buscar usuario por email
  const user = await User.findByEmail(email);
  if (!user) return res.status(400).json({ msg: 'Credenciales inválidas' });

  // Verificar si la contraseña es correcta
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(400).json({ msg: 'Credenciales inválidas' });

  // Generar token JWT con el ID del usuario
  const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  });
  
  // Devolver token y nombre del usuario
  res.json({ token, nombre: user.nombre });
};