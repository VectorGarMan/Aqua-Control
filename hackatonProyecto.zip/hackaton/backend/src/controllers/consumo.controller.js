// Importar el modelo de Consumo que maneja las operaciones con la base de datos
const Consumo = require('../models/consumo.model');

// Controlador para registrar un nuevo consumo de agua
exports.registrarConsumo = async (req, res) => {
  const user_id = req.userId;  // ID del usuario extraído del token JWT
  const { litros, fecha } = req.body;  // Datos del consumo desde el cuerpo de la petición
  
  // Crear nuevo registro de consumo en la base de datos
  const id = await Consumo.create({ user_id, litros, fecha });
  
  // Responder con el ID del nuevo registro creado
  res.status(201).json({ id });
};

// Controlador para obtener los consumos de los últimos 7 días del usuario
exports.getMisConsumos = async (req, res) => {
  // Obtener registros de consumo filtrados por usuario y fecha
  const data = await Consumo.findLast7Days(req.userId);
  
  // Devolver los datos encontrados
  res.json(data);
};

// Controlador para obtener el promedio de consumo de todos los usuarios
exports.getPromedio = async (req, res) => {
  // Calcular el promedio de consumo de los últimos 7 días
  const data = await Consumo.avgAllUsersLast7Days();
  
  // Devolver el resultado del cálculo
  res.json(data);
};