const router = require('express').Router();
const auth = require('../middleware/auth.middleware');
const {
  registrarConsumo,
  getMisConsumos,
  getPromedio
} = require('../controllers/consumo.controller');

router.post('/', auth, registrarConsumo);
router.get('/', auth, getMisConsumos);
router.get('/promedio', auth, getPromedio);

module.exports = router;