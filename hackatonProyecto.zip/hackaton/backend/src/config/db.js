// Importamos el módulo mysql2 con soporte para Promises
const mysql = require('mysql2/promise');

// Desestructuramos las variables de entorno necesarias para la conexión
const { DB_HOST, DB_USER, DB_PASSWORD, DB_NAME } = process.env;

// Creamos un pool de conexiones a MySQL con las siguientes configuraciones:
const pool = mysql.createPool({
  host: DB_HOST,          // Dirección del servidor de base de datos
  user: DB_USER,          // Usuario de MySQL
  password: DB_PASSWORD,  // Contraseña del usuario
  database: DB_NAME,      // Nombre de la base de datos
  waitForConnections: true,  // Espera si no hay conexiones disponibles
  connectionLimit: 10        // Número máximo de conexiones en el pool
});

// Exportamos el pool de conexiones para su uso en otros módulos
module.exports = pool;