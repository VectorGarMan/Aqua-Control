// Importar la configuración del pool de conexiones a la base de datos
const db = require('../config/db');

// Definición del modelo User con métodos para gestionar usuarios en la base de datos
const User = {
  // Crear un nuevo usuario en la base de datos
  // @param {Object} params - Objeto con nombre, email y password del usuario
  // @param {string} params.nombre - Nombre completo del usuario
  // @param {string} params.email - Email único del usuario
  // @param {string} params.password - Contraseña hasheada del usuario
  // @returns {Number} ID del nuevo usuario creado
  async create({ nombre, email, password }) {
    const [result] = await db.execute(
      'INSERT INTO users (nombre, email, password) VALUES (?, ?, ?)',
      [nombre, email, password]
    );
    return result.insertId;
  },

  // Buscar un usuario por su email
  // @param {string} email - Email del usuario a buscar
  // @returns {Object|null} Datos del usuario encontrado o null
  async findByEmail(email) {
    const [rows] = await db.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    return rows[0];
  }
};

// Exportar el modelo para su uso en otros módulos
module.exports = User;