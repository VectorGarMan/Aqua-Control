// Importar la configuración de la base de datos
const db = require('../config/db');

// Definición del modelo Consumo con sus métodos de acceso a datos
const Consumo = {
  // Crear un nuevo registro de consumo
  // @param {Object} params - Objeto con user_id, litros y fecha
  // @returns {Number} ID del nuevo registro
  async create({ user_id, litros, fecha }) {
    const [result] = await db.execute(
      'INSERT INTO consumos (user_id, litros, fecha) VALUES (?, ?, ?)',
      [user_id, litros, fecha]
    );
    return result.insertId;
  },

  // Obtener los consumos de los últimos 7 días para un usuario específico
  // @param {Number} user_id - ID del usuario
  // @returns {Array} Registros de consumo con fecha y litros
  async findLast7Days(user_id) {
    const [rows] = await db.execute(
      `SELECT fecha, litros
       FROM consumos
       WHERE user_id = ? AND fecha >= CURDATE() - INTERVAL 6 DAY
       ORDER BY fecha`,
      [user_id]
    );
    return rows;
  },

  // Calcular el promedio de consumo diario de todos los usuarios en los últimos 7 días
  // @returns {Array} Promedios por fecha
  async avgAllUsersLast7Days() {
    const [rows] = await db.execute(
      `SELECT fecha, ROUND(AVG(litros),2) AS promedio
       FROM consumos
       WHERE fecha >= CURDATE() - INTERVAL 6 DAY
       GROUP BY fecha
       ORDER BY fecha`
    );
    return rows;
  }
};

// Exportar el modelo para su uso en otros módulos
module.exports = Consumo;