-- Creación de la base de datos principal si no existe
CREATE DATABASE IF NOT EXISTS agua_mvp;
USE agua_mvp;

-- Tabla de usuarios
-- Almacena la información básica de los usuarios registrados
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,  -- Identificador único del usuario
  nombre VARCHAR(100) NOT NULL,       -- Nombre completo del usuario
  email VARCHAR(150) NOT NULL UNIQUE, -- Correo electrónico (único) para login
  password VARCHAR(255) NOT NULL,     -- Contraseña encriptada
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP  -- Fecha y hora de registro
);

-- Tabla de consumos diarios de agua
-- Registra el consumo de agua por usuario por día
CREATE TABLE IF NOT EXISTS consumos (
  id INT AUTO_INCREMENT PRIMARY KEY,   -- Identificador único del registro
  user_id INT NOT NULL,               -- ID del usuario que registró el consumo
  litros INT NOT NULL,                -- Cantidad de litros consumidos
  fecha DATE NOT NULL,                -- Fecha del consumo
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,  -- Fecha y hora del registro
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE  -- Relación con tabla users, se eliminan registros si se elimina el usuario
);