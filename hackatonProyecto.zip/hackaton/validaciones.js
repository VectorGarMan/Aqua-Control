// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function () {
  // URL base de la API para las peticiones
  const API_URL = 'http://localhost:4000/api';

  // Referencias a elementos del formulario
  const registerForm = document.getElementById('registerForm');
  const nameInput = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');

  // Manejar el envío del formulario
  registerForm.addEventListener('submit', async function (e) {
    e.preventDefault();

    // Validar todos los campos antes del envío
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();

    // Si todas las validaciones pasan, proceder con el registro
    if (isNameValid && isEmailValid && isPasswordValid) {
      const submitButton = registerForm.querySelector('button[type="submit"]');
      submitButton.classList.add('loading');
      submitButton.disabled = true;
      submitButton.textContent = 'Registrando...';

      try {
        // Enviar petición de registro al servidor
        const res = await fetch(`${API_URL}/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            nombre: nameInput.value.trim(),
            email: emailInput.value.trim(),
            password: passwordInput.value
          })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.msg || 'Error en el registro');

        // Registro exitoso: redirigir a login
        window.location.href = 'login.html';
      } catch (err) {
        // Mostrar error de registro en el formulario
        const formError = document.createElement('div');
        formError.className = 'auth-error';
        formError.textContent = err.message;
        registerForm.prepend(formError);

        // Restaurar estado del botón
        submitButton.classList.remove('loading');
        submitButton.disabled = false;
        submitButton.textContent = 'Registrarse';
      }
    }
  });

  // Configurar validación en tiempo real
  nameInput.addEventListener('input', validateName);
  emailInput.addEventListener('input', validateEmail);
  passwordInput.addEventListener('input', validatePassword);

  // Función de validación para el nombre
  function validateName() {
    const name = nameInput.value.trim();
    const errorElement = document.getElementById('name-error');

    // Validaciones específicas para el nombre
    if (name.length === 0) {
      showError(nameInput, errorElement, 'El nombre es requerido');
      return false;
    }
    if (name.length < 3) {
      showError(nameInput, errorElement, 'Mínimo 3 caracteres');
      return false;
    }
    if (name.length > 50) {
      showError(nameInput, errorElement, 'Máximo 50 caracteres');
      return false;
    }
    if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(name)) {
      showError(nameInput, errorElement, 'Solo letras y espacios');
      return false;
    }
    showSuccess(nameInput, errorElement);
    return true;
  }

  // Función de validación para el email
  function validateEmail() {
    const email = emailInput.value.trim();
    const errorElement = document.getElementById('email-error');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Validaciones específicas para el email
    if (email.length === 0) {
      showError(emailInput, errorElement, 'El email es requerido');
      return false;
    }
    if (!emailRegex.test(email)) {
      showError(emailInput, errorElement, 'Email no válido');
      return false;
    }
    showSuccess(emailInput, errorElement);
    return true;
  }

  // Función de validación para la contraseña
  function validatePassword() {
    const password = passwordInput.value;
    const errorElement = document.getElementById('password-error');
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d).{8,}$/;

    // Validaciones específicas para la contraseña
    if (password.length === 0) {
      showError(passwordInput, errorElement, 'La contraseña es requerida');
      return false;
    }
    if (password.length < 8) {
      showError(passwordInput, errorElement, 'Mínimo 8 caracteres');
      return false;
    }
    if (!passwordRegex.test(password)) {
      showError(passwordInput, errorElement, 'Debe contener una mayúscula y un número');
      return false;
    }
    showSuccess(passwordInput, errorElement);
    return true;
  }

  // Funciones auxiliares para mostrar estados de validación
  function showError(input, errorElement, message) {
    errorElement.textContent = message;
    input.style.borderColor = '#ff6b6b';
    input.style.backgroundColor = '#fff9f9';
  }

  function showSuccess(input, errorElement) {
    errorElement.textContent = '';
    input.style.borderColor = '#51cf66';
    input.style.backgroundColor = '#f8fff9';
  }

  // Configurar eventos de focus para mejorar UX
  [nameInput, emailInput, passwordInput].forEach((input) => {
    input.addEventListener('focus', function () {
      this.style.borderColor = '#0099cc';
      this.style.backgroundColor = '#ffffff';
      const authError = document.querySelector('.auth-error');
      if (authError) authError.remove();
    });
  });
});