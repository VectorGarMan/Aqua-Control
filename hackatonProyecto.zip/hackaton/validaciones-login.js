// validaciones-login.js
// Esperar a que el DOM esté completamente cargado antes de ejecutar el código
document.addEventListener('DOMContentLoaded', function () {
  // Configuración de la URL base de la API
  const API_URL = 'http://localhost:4000/api'; 

  // Obtener referencias a elementos del DOM
  const loginForm = document.getElementById('loginForm');
  const emailInput = document.getElementById('login-email');
  const passwordInput = document.getElementById('login-password');

  // Manejar el envío del formulario
  loginForm.addEventListener('submit', async function (e) {
    e.preventDefault();
    // Eliminar mensaje de error previo si existe
    const prevErr = document.querySelector('.auth-error');
    if (prevErr) prevErr.remove();

    // Validación básica de campos requeridos
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    if (!email || !password) {
      showAuthError('Todos los campos son obligatorios');
      return;
    }

    // Actualizar estado del botón durante la petición
    const btn = loginForm.querySelector('button[type="submit"]');
    btn.classList.add('loading');
    btn.disabled = true;
    btn.textContent = 'Entrando...';

    try {
      // Realizar petición de login al servidor
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.msg || 'Credenciales inválidas');

      // Si login exitoso, guardar token y redirigir
      localStorage.setItem('token', data.token);
      window.location.href = 'consumo.html';
    } catch (err) {
      // Manejar errores de autenticación
      showAuthError(err.message);
      btn.classList.remove('loading');
      btn.disabled = false;
      btn.textContent = 'Iniciar sesión';
    }
  });

  // Validación en tiempo real de campos
  emailInput.addEventListener('input', validateEmail);
  passwordInput.addEventListener('input', validatePassword);

  // Función para validar formato de email
  function validateEmail() {
    const email = emailInput.value.trim();
    const errEl = document.getElementById('email-error');
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email === '') {
      showError(emailInput, errEl, 'El email es requerido');
      return false;
    }
    if (!regex.test(email)) {
      showError(emailInput, errEl, 'Email no válido');
      return false;
    }
    showSuccess(emailInput, errEl);
    return true;
  }

  // Función para validar contraseña
  function validatePassword() {
    const pwd = passwordInput.value;
    const errEl = document.getElementById('password-error');
    if (pwd === '') {
      showError(passwordInput, errEl, 'La contraseña es requerida');
      return false;
    }
    showSuccess(passwordInput, errEl);
    return true;
  }

  // Función para mostrar errores de validación
  function showError(input, errEl, msg) {
    errEl.textContent = msg;
    input.style.borderColor = '#ff6b6b';
    input.style.backgroundColor = '#fff9f9';
  }

  // Función para mostrar estado de éxito en validación
  function showSuccess(input, errEl) {
    errEl.textContent = '';
    input.style.borderColor = '#51cf66';
    input.style.backgroundColor = '#f8fff9';
  }

  // Función para mostrar errores de autenticación
  function showAuthError(msg) {
    const div = document.createElement('div');
    div.className = 'auth-error';
    div.textContent = msg;
    loginForm.prepend(div);
    emailInput.style.borderColor = '#ff6b6b';
    passwordInput.style.borderColor = '#ff6b6b';
  }
});