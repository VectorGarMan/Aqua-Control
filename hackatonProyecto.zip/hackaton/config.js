// Configuración central de la aplicación
// Define variables según el entorno de ejecución

const config = {
  // Configuración para entorno de desarrollo local
  development: {
    API_URL: 'http://localhost:4000/api',  // URL base de la API en desarrollo
  },
  
  // Configuración para entorno de producción
  production: {
    API_URL: 'https://tu-api-production.com/api/v1',  // URL base de la API en producción
  },
};

// Determinar el entorno actual (development por defecto)
const env = process.env.NODE_ENV || 'development';

// Exportar la configuración correspondiente al entorno actual
export default config[env];
